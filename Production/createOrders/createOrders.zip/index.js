/***** https://www.jeremydaly.com/reuse-database-connections-aws-lambda/ ****/

const mysql = require('mysql2'); // require mysql
var moment = require("moment-timezone");


// If 'client' variable doesn't exist
if (typeof client === 'undefined') {
  // Connect to the MySQL database
  var client = mysql.createConnection({
        host: process.env.RDS_LAMBDA_HOSTNAME,
        user: process.env.RDS_LAMBDA_USERNAME,
        password: process.env.RDS_LAMBDA_PASSWORD,
        port: process.env.RDS_LAMBDA_PORT,
        database: process.env.RDS_DATABASE,
  });
 
  client.connect()
}
 
exports.handler = (event, context, callback) => {

  console.log('Received event:', JSON.stringify(event, null, 2));
  let newOrder = JSON.stringify(event)
  newOrder = JSON.parse(newOrder)
  console.log('Color Name: ', newOrder.body.colorName);

  var date = new Date();
  console.log("time in germany: " + moment(date.getTime()).tz("America/Los_Angeles").format("DD-MM-YYYY"));

  // This will allow us to freeze open connections to a database
  context.callbackWaitsForEmptyEventLoop = false;

  let newOrderString = "INSERT INTO testdb.ProductionDB values(" + date.toDateString + "," + "," + ")"
 
//   client.query("INSERT INTO testdb.ProductionDB values('2018/03/29','11:12:13','C-20170327-90125','Schmidt','Achim','Langestraße 5',77723,'Gengenbach','Deutschland',10000002,'#009900',1,'Y',3455)",
//   function (error, results) {
//     callback(null, results)
//   });

  client.query("SELECT * FROM testdb.ProductionDB LIMIT 10;",
  function (error, results) {
    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
          data: 'Neue Aufträge wurden erfolgreich zur Datenbank hinzugefügt!',
          dataReturn: results      
      })
    });  
  });  
}
